// Acezone starter front-end. Configure the WhatsApp number and API URL before publishing.
const CONFIG = {
  whatsappNumber: "2349013964797", // Replace with the official Acezone WhatsApp number, digits only.
};
const $ = (selector) => document.querySelector(selector);
$("#year").textContent = new Date().getFullYear();

const menuToggle = $("#menuToggle");
const mainNav = $("#mainNav");
menuToggle.addEventListener("click", () => mainNav.classList.toggle("open"));
mainNav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => mainNav.classList.remove("open")));

const wa = $("#whatsappLink");
if (CONFIG.whatsappNumber && CONFIG.whatsappNumber !== "2340000000000") {
  wa.href = `https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent("Hello Acezone, I would like to know more about your JAMB tutorials.")}`;
} else {
  wa.href = "https://wa.me/";
  wa.addEventListener("click", e => { if (!CONFIG.whatsappNumber) { e.preventDefault(); toast("Add the official WhatsApp number in public/app.js first."); } });
}

const questions = [
  {subject:"Physics", q:"Which of the following is the SI unit of force?", options:["Joule","Newton","Watt","Pascal"], answer:1, explanation:"Force is measured in newtons (N). One newton is the force needed to accelerate 1 kg at 1 m/s²."},
  {subject:"Chemistry", q:"What is the pH of a neutral aqueous solution at 25°C?", options:["0","5","7","14"], answer:2, explanation:"At 25°C, a neutral aqueous solution has pH 7 because the hydrogen and hydroxide ion concentrations are equal."},
  {subject:"Biology", q:"Which cell organelle is primarily responsible for aerobic respiration?", options:["Ribosome","Mitochondrion","Golgi apparatus","Vacuole"], answer:1, explanation:"Mitochondria are the main site of aerobic respiration and ATP production in eukaryotic cells."}
];
let qIndex = 0, answers = Array(questions.length).fill(null), submitted = false;
function renderQuestion() {
  const q = questions[qIndex];
  $("#questionCount").textContent = `Question ${qIndex+1} of ${questions.length}`;
  $("#quizProgress").style.width = `${((qIndex+1)/questions.length)*100}%`;
  $("#quizContent").innerHTML = `<p class="eyebrow">${q.subject.toUpperCase()}</p><h3 class="question-title">${q.q}</h3><div class="options">${q.options.map((option,i)=>`<label class="option ${answers[qIndex]===i?'selected':''}"><input type="radio" name="answer" value="${i}" ${answers[qIndex]===i?'checked':''} ${submitted?'disabled':''}><span><b>${String.fromCharCode(65+i)}.</b> ${option}</span></label>`).join("")}</div>${submitted?`<div class="quiz-result"><b>Explanation:</b> ${q.explanation}</div>`:""}`;
  $("#prevQuestion").disabled = qIndex === 0;
  $("#nextQuestion").classList.toggle("hidden", qIndex === questions.length-1 || submitted);
  $("#submitQuiz").classList.toggle("hidden", qIndex !== questions.length-1 || submitted);
  if (submitted) { $("#nextQuestion").classList.add("hidden"); $("#submitQuiz").classList.add("hidden"); }
  $("#quizContent").querySelectorAll('input[name="answer"]').forEach(input => input.addEventListener("change", () => { answers[qIndex] = Number(input.value); renderQuestion(); }));
}
$("#prevQuestion").addEventListener("click", () => { if(qIndex>0){qIndex--;renderQuestion();} });
$("#nextQuestion").addEventListener("click", () => { if(qIndex<questions.length-1){qIndex++;renderQuestion();} });
$("#submitQuiz").addEventListener("click", () => {
  if (answers.some(a => a === null)) { toast("Please answer all three questions before submitting."); return; }
  submitted = true; renderQuestion();
  const score = answers.reduce((total,a,i)=>total+(a===questions[i].answer?1:0),0);
  $("#quizResult").classList.remove("hidden");
  $("#quizResult").innerHTML = `<b>Your score: ${score}/${questions.length}</b><br>Review each explanation to strengthen your understanding. <button id="retryQuiz" class="btn btn-ghost" style="margin-top:10px">Try again</button>`;
  $("#retryQuiz").addEventListener("click", () => {qIndex=0;answers=Array(questions.length).fill(null);submitted=false;$("#quizResult").classList.add("hidden");renderQuestion();});
});
renderQuestion();

$("#adminInfoBtn").addEventListener("click",()=>$("#adminInfo").classList.toggle("hidden"));
let toastTimer;
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2600);}
