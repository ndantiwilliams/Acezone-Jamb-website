# Acezone JAMB Tutorials — no-AI starter website

This version removes the AI tutor interface and AI backend.

## Included
- Responsive Acezone landing page
- Sample CBT practice with answer selection, scoring and explanations
- Demo student dashboard (illustrative sample data only)
- WhatsApp enrollment link
- Admin setup information (not a real authenticated admin panel)

## Configure WhatsApp
Open `public/app.js` and replace `whatsappNumber` with the official Acezone number in international format, digits only. For Nigeria, use `234` followed by the number without its leading zero. Confirm the number before publishing.

## Deploy from Android
1. Extract the ZIP.
2. Create a GitHub repository and upload the contents of the `public` folder to the repository root.
3. In your static hosting provider / EdgeOne Pages, import the repository.
4. Set the output directory to the repository root and leave the build command empty.
5. Deploy and open the generated URL.

## Before using with real students
The student dashboard uses demo data. A production student account system and admin area require a secure backend, authentication, a database, and role-based access controls. The sample CBT questions are examples only; add reviewed and properly licensed questions before using it as a full question bank.
